package websocket;

import java.io.IOException;
import java.util.HashMap;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/server")
public class WebSocketServer{
	
	private HashMap<String, Session> sessionMap = new HashMap<>();
	
	private int zaehler = 1;
	
    @OnOpen
    public void onOpen(Session session){
    	sessionMap.put("Player" + zaehler,session);
        System.out.println("onOpen:: " + "Player" + zaehler + " with id:: " +session.getId());        
        zaehler++;
        System.out.println(zaehler);
    }
    @OnClose
    public void onClose(Session session){
        System.out.println("onClose::" +  session.getId());
    }
    
    @OnMessage
    public void onMessage(String msg, Session session) throws IOException {
        
        if(session.isOpen()) {
        	
        	System.out.println("onMessage::From= " + session.getId() + " Message= " + msg);
        	
        	
        	
        }
        
    }
    
    @OnError
    public void onError(Throwable t){
        System.out.println("onError::" + t.getMessage());
    }
	
}
